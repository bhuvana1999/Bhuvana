export interface IEmployee {
    empId: number;
    empName: string;
    empEmail: string;
    empPhone: string;
}
